#############################################################################################
#                                                                                           #
#                                     DEFINITION                                            #
#                                                                                           #
#############################################################################################

import sqlite3
import pandas as pd
import numpy as np
import os, csv

#############################################################################################
#                                                                                           #
#                                         CODE                                              #
#                                                                                           #
#############################################################################################

class DatabaseManager:
    def __init__(self, db_name='courses_chevaux.db'):
        self.db_name = db_name
        
        
        self.create_database()
        
        

    def fetch_all_data(self, table_name):
        conn = sqlite3.connect(self.db_name)
        # Fetch all data from the specified table and return it as a DataFrame
        query = f'SELECT * FROM {table_name}'
        df = pd.read_sql_query(query, conn)
        return df

    def create_database(self):
        # Connexion à la base de données SQLite (ou création si elle n'existe pas)
        #FOR BLACKBOX : We want to have in this database the past races results which will give us winning trio of horses and their respective jockey
        ## Then we want to store each horse and jockey in it's own table
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        # Création des tables
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS cavalier (
            id_cavalier INTEGER PRIMARY KEY AUTOINCREMENT,
            nom_cavalier TEXT NOT NULL,
            starts INTEGER,
            firsts INTEGER,
            seconds INTEGER,
            thirds INTEGER,
            win_percentage REAL,
            top_three_percentage REAL
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS chevaux (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rank INTEGER,
            nom_cheval TEXT,
            id_cavalier INTEGER,
            moyenne_des_rang INTEGER,
            starts INTEGER,
            firsts INTEGER,
            seconds INTEGER,
            thirds INTEGER,
            win_percentage REAL,
            top_three_percentage REAL,
            FOREIGN KEY (id_cavalier) REFERENCES cavalier (id_cavalier) ON DELETE CASCADE
        );
        ''')

        cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id_course VARCHAR(20) PRIMARY KEY,
            date DATE NOT NULL,
            track_id INTEGER NOT NULL,
            status TEXT CHECK(status IN ('scheduled', 'completed')) DEFAULT 'scheduled'
        );
        ''')


        cursor.execute('''
        CREATE TABLE IF NOT EXISTS resultats (
            id_resultat INTEGER PRIMARY KEY AUTOINCREMENT,
            race_id VARCHAR(20),
            horse_id INTEGER,
            cavalier_id INTEGER,
            position INTEGER,
            win BOOLEAN,
            place BOOLEAN,
            show BOOLEAN,
            FOREIGN KEY (race_id) REFERENCES courses (id_course) ON DELETE CASCADE,
            FOREIGN KEY (horse_id) REFERENCES cheveaux (id) ON DELETE CASCADE,
            FOREIGN KEY (cavalier_id) REFERENCES cavalier (id_cavalier) ON DELETE CASCADE
        );
        ''')

        conn.commit()
        conn.close()
        print("Base de données et tables créées avec succès.")

    def insert_into_table(self, table_name, data):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        try:
            if table_name == 'cavalier':
                cursor.execute('INSERT INTO cavalier (nom_cavalier) VALUES (?);', (data['nom_cavalier'],))

            elif table_name == 'cheveaux':
                cursor.execute(
                    'INSERT INTO cheveaux (nom_cheval, id_cavalier, moyenne_des_rang) VALUES (?, ?, ?);',
                    (data['nom_cheval'], data['id_cavalier'], data['moyenne_des_rang']))

            elif table_name == 'courses':
                cursor.execute('INSERT INTO courses (race_id, date, track_id, status) VALUES (?, ?, ?, ?);',
                               (data['race_id'], data['date'], data['track_id'], data['status']))

            elif table_name == 'resultats':
                cursor.execute('INSERT INTO resultats (race_id ,horse_id , cavalier_id ,position , win ,place ,show ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);',
                               (data['race_id'], data['spot'], data['id_cheval'], data['id_cavalier'], data['position'], data['win'], data['place'], data['show']))

            else:
                print(f"Table '{table_name}' non reconnue.")
                return

            conn.commit()
            print(f"Données insérées avec succès dans la table '{table_name}'.")

        except sqlite3.Error as e:
            print(f"Erreur lors de l'insertion dans la table '{table_name}': {e}")

        finally:
            conn.close()

    def insert_RS247_csv(self):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        #Let's read theses following csv and save it into the sqlite3 database
        #cheveaux.csv columns:Rank,Top Horses by Wins,Starts,1st,2nd,3rd,Win %,Top 3 %,Rang,Top Chevaux en Fonction des Victoires,Départ,1ère,2e,3e,Victoires %
        #cavaliers.csv columns: Rank,Top Jockeys by Wins,Starts,1st,2nd,3rd,Win %,Top 3 %,Rang,Top Jockeys par Victoires,Départ,1ère,2e,3e,Victoires %
        chevaux_file = 'cheveaux.csv'
        cavaliers_file = 'cavaliers.csv'
        
        chevaux_df = pd.read_csv(chevaux_file)
        cavaliers_df = pd.read_csv(cavaliers_file)
        for index, row in chevaux_df.iterrows():
            cursor.execute('''
                INSERT INTO chevaux (rank, nom_cheval, starts, firsts, seconds, thirds, win_percentage, top_three_percentage)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (row['Rank'], row['Top Horses by Wins'], row['Starts'], row['1st'], row['2nd'], row['3rd'], row['Win %'], row['Top 3 %']))
        for index, row in cavaliers_df.iterrows():
            cursor.execute('''
                INSERT INTO cavaliers (rank, nom_cavalier, starts, firsts, seconds, thirds, win_percentage, top_three_percentage)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (row['Rank'], row['Top Jockeys by Wins'], row['Starts'], row['1st'], row['2nd'], row['3rd'], row['Win %'], row['Top 3 %']))
        
        conn.commit()
        cursor.close()

    def is_table_empty(self, table_name):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        # Check if the specified table is empty
        query = f'SELECT COUNT(*) FROM {table_name}'
        cursor.execute(query)
        count =cursor.fetchone()[0]
        cursor.close()# Fetch the count from the result
        return count == 0

    def display_table(self, table_name):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        try:
            cursor.execute(f'SELECT * FROM {table_name};')
            rows = cursor.fetchall()

            if not rows:
                print(f"La table '{table_name}' est vide.")
                return

            column_names = [description[0] for description in cursor.description]
            print(f"Contenu de la table '{table_name}':")
            print("\t".join(column_names))

            for row in rows:
                print("\t".join(map(str, row)))

        except sqlite3.Error as e:
            print(f"Erreur lors de l'accès à la table '{table_name}': {e}")

        finally:
            conn.close()

    def update_record(self, table_name, record_id, data):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        try:
            if table_name == 'cavalier':
                cursor.execute('UPDATE cavalier SET nom_cavalier = ? WHERE id_cavalier = ?;',
                               (data['nom_cavalier'], record_id))

            elif table_name == 'cheveaux':
                cursor.execute(
                    'UPDATE cheveaux SET nom_cheval = ?, id_cavalier = ?, moyenne_des_rang = ? WHERE id = ?;',
                    (data['nom_cheval'], data['id_cavalier'], data['moyenne_des_rang'], record_id))

            elif table_name == 'course_futures':
                cursor.execute('UPDATE course_futures SET trac = ?, date = ?, cheaux_qui_participe = ? WHERE id = ?;',
                               (data['trac'], data['date'], data['cheaux_qui_participe'], record_id))

            elif table_name == 'course_passées':
                cursor.execute('UPDATE course_passées SET trac = ?, date = ?, les_trois_gagnants = ? WHERE id = ?;',
                               (data['trac'], data['date'], data['les_trois_gagnants'], record_id))

            elif table_name == 'participation':
                cursor.execute(
                    'UPDATE participation SET id_cheval = ?, id_course = ?, is_future_course = ? WHERE id = ?;',
                    (data['id_cheval'], data['id_course'], data['is_future_course'], record_id))

            else:
                print(f"Table '{table_name}' non reconnue.")
                return

            conn.commit()
            print(f"Enregistrement mis à jour avec succès dans la table '{table_name}'.")

        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour dans la table '{table_name}': {e}")

        finally:
            conn.close()