from .Scrapper import Scrapper
from .DB_manager import DatabaseManager