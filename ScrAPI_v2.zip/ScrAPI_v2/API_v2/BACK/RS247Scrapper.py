#############################################################################################
#                                                                                           #
#                                     DEFINITION                                            #
#                                                                                           #
#############################################################################################

import pandas as pd
import scrapy   
import requests 
from bs4 import BeautifulSoup
import os

#############################################################################################
#                                                                                           #
#                                         CODE                                              #
#                                                                                           #
#############################################################################################

class RS247Scrapper:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.Jurls = [
            "https://us.racingstats247.com/jockeys/United-States/",
            "https://www.racingstats247.com/jockeys/United-Kingdom/",
            "https://fr.racingstats247.com/jockeys/France/",
            "https://ca.racingstats247.com/jockeys/Canada/",
            "https://ie.racingstats247.com/jockeys/Ireland/"
        ]
        self.Hurls =[
            "https://us.racingstats247.com/horses/United-States/",
            "https://www.racingstats247.com/horses/United-Kingdom/",
            "https://fr.racingstats247.com/chevaux/France/",
            "https://ca.racingstats247.com/horses/Canada/",
            "https://ie.racingstats247.com/horses/Ireland/"
        ]
                
        
        
    def get_cavaliers_csv(self):
        self.all_dataframes = []
        for url in self.Jurls:   ##boucle pour recuperer les donnees dans chaque url
            headers = {
            'User -Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
        }
            try:
                reponse = requests.get(url, headers=headers) ##requete get pour recuperer les pages
                reponse.raise_for_status()  # Vérifie les erreurs HTTP
                soup = BeautifulSoup(reponse.text, "html.parser")
                table = soup.find('table', id='racingContentPlaceHolder_gvTopJockeys')#CHERCHE LES DONNEES DANS CHAQUE PAGES
                
                if table:
                    headers = [th.get_text(strip=True) for th in table.find_all("th")]
                    rows = []
                    for tr in table.find_all("tr")[1:]:
                        cols = tr.find_all("td")
                        if len(cols) > 1:
                            rows.append([col.get_text(strip=True) for col in cols])
                    df = pd.DataFrame(rows, columns=headers)
                    self.all_dataframes.append(df)
                    print(df.head())
                else:
                    print(f'Erreur lors de la récupération du tableau pour {url}')
            except requests.exceptions.RequestException as e:
                print(f"Erreur lors de la récupération de la page {url}: {e}")

        # Exporter toutes les données dans un seul fichier CSV
        if self.all_dataframes:
            final_df = pd.concat(self.all_dataframes, ignore_index=True)
            final_df.to_csv("cavaliers.csv", index=False)
            print("Les données ont été exportées dans 'cavaliers.csv'.")
        else:
            print("Aucune donnée à exporter.")
            
            
    def get_chevaux_csv(self):
        self.all_dataframes = []
        for url in self.Hurls:   ##boucle pour recuperer les donnees dans chaque url
            headers = {
            'User -Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
        }
            try:
                reponse = requests.get(url, headers=headers) ##requete get pour recuperer les pages
                reponse.raise_for_status()  # Vérifie les erreurs HTTP
                soup = BeautifulSoup(reponse.text, "html.parser")
                table = soup.find('table', id='racingContentPlaceHolder_gvTopHorses')
                
                if table:
                    headers = [th.get_text(strip=True) for th in table.find_all("th")]
                    rows = []
                    for tr in table.find_all("tr")[1:]:
                        cols = tr.find_all("td")
                        if len(cols) > 1:
                            rows.append([col.get_text(strip=True) for col in cols])
                    df = pd.DataFrame(rows, columns=headers)
                    self.all_dataframes.append(df)
                    print(df.head())
                else:
                    print(f'Erreur lors de la récupération du tableau pour {url}')
            except requests.exceptions.RequestException as e:
                print(f"Erreur lors de la récupération de la page {url}: {e}")

        # Exporter toutes les données dans un seul fichier CSV
        if self.all_dataframes:
            final_df = pd.concat(self.all_dataframes, ignore_index=True)
            final_df.to_csv("cheveaux.csv", index=False)
            print("Les données ont été exportées dans 'cheveaux.csv'.")
        else:
            print("Aucune donnée à exporter.")
 
    def run_scrap(self):
        if not os.path.exists("cavaliers.csv"):
            self.get_cavaliers_csv()
        if not os.path.exists("cheveaux.csv"):
            self.get_chevaux_csv()
        
        
        
    def create_new_csv(data, filename='data.csv'):
    # Check if the file already exists
        if os.path.exists(filename):
            print(f"{filename} already exists. Please delete it or choose a different name.")
            return  # Exit the function if the file exists

        # If the file doesn't exist, create a new CSV file
        df = pd.DataFrame(data)  # Assuming 'data' is a list of dictionaries or similar
        df.to_csv(filename, index=False)
        print(f"{filename} has been created successfully.")