#############################################################################################
#                                                                                           #
#                                     DEFINITION                                            #
#                                                                                           #
#############################################################################################
import os
import tkinter as tk
from tkinter import ttk, messagebox
from API_v2.FRONT import Screens
from API_v2.BACK import DRFScrapper, RS247Scrapper, DatabaseManager
#############################################################################################
#                                                                                           #
#                                         CODE                                              #
#                                                                                           #
#############################################################################################

class API_GUI:
    def __init__(self, Dscrapper : DRFScrapper , Rscraper : RS247Scrapper,db_manager = DatabaseManager) :
        self.root = tk.Tk()
        self.root.title("TOUT SUR COMMENCEMENT")
        self.root.minsize(400, 300)
        
        self.DRFscrapper = Dscrapper
        self.RS247scrapper = Rscraper
        if not os.path.exists("cavaliers.csv") and not os.path.exists("cheveaux.csv"):
            self.RS247scrapper.run_scrap()
        self.db_manager = db_manager
        if  os.path.exists("cavaliers.csv") and  os.path.exists("cheveaux.csv") and self.db_manager.is_table_empty("chevaux")and self.db_manager.is_table_empty("cavalier"):
            self.db_manager.insert_RS247_csv()
        self.screen_manager = Screens.ScreenManager(self)
        self.screen_manager.show_screen("HomeScreen")
        
        
    
    def run(self):
        print("running API...")
        self.root.mainloop()