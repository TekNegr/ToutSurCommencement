from .Scr_API import ScrAPI
from .FRONT import GUI, Screens
from .BACK import DRFScrapper, RS247Scrapper, DatabaseManager

__version__ = "2.0"
__all__ = ["ScrAPI", "FRONT", "BACK"]